require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "";
if (process.env.NODE_ENV === "production" && JWT_SECRET.length < 32) {
  throw new Error("Set a strong JWT_SECRET (at least 32 characters) in production.");
}
if (!process.env.JWT_SECRET) console.warn("WARNING: Set JWT_SECRET in .env before public deployment.");

const dbFile = path.resolve(process.env.DATABASE_FILE || "./data/bharatsevak.sqlite");
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const uploadDir = path.resolve(process.env.UPLOAD_DIR || "./uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const db = new Database(dbFile);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'master_admin',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS books (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 class_name TEXT NOT NULL DEFAULT '',
 subject TEXT NOT NULL DEFAULT '',
 language TEXT NOT NULL DEFAULT 'বাংলা',
 description TEXT NOT NULL DEFAULT '',
 pdf_filename TEXT,
 published INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS lessons (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 book_id INTEGER NOT NULL,
 title TEXT NOT NULL,
 content TEXT NOT NULL DEFAULT '',
 sort_order INTEGER NOT NULL DEFAULT 0,
 published INTEGER NOT NULL DEFAULT 1,
 FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS quizzes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 lesson_id INTEGER NOT NULL,
 question TEXT NOT NULL,
 options_json TEXT NOT NULL,
 answer_index INTEGER NOT NULL,
 explanation TEXT NOT NULL DEFAULT '',
 FOREIGN KEY(lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS exam_results (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 lesson_id INTEGER NOT NULL,
 score INTEGER NOT NULL,
 total INTEGER NOT NULL,
 submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
db.pragma("foreign_keys = ON");

async function ensureAdmin() {
  const username = process.env.ADMIN_USERNAME;
  const password = process.env.ADMIN_PASSWORD;
  if (!username || !password) {
    console.warn("ADMIN_USERNAME/ADMIN_PASSWORD not set; create admin credentials before using admin panel.");
    return;
  }
  const exists = db.prepare("SELECT id FROM admins WHERE username = ?").get(username);
  if (!exists) {
    const hash = await bcrypt.hash(password, 12);
    db.prepare("INSERT INTO admins(username,password_hash,role) VALUES(?,?,?)").run(username, hash, "master_admin");
    console.log("Initial Master Admin created from environment settings.");
  }
}

app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use("/api/admin", rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));

function auth(req, res, next) {
  const value = req.headers.authorization || "";
  const token = value.startsWith("Bearer ") ? value.slice(7) : "";
  try {
    req.admin = jwt.verify(token, JWT_SECRET || "local-dev-only-change-me");
    next();
  } catch {
    return res.status(401).json({ error: "লগইন প্রয়োজন। আবার লগইন করুন।" });
  }
}
function requireMaster(req, res, next) {
  if (req.admin?.role !== "master_admin") return res.status(403).json({ error: "Master Admin অনুমতি প্রয়োজন।" });
  next();
}
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2,10)}.pdf`)
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype !== "application/pdf" || !file.originalname.toLowerCase().endsWith(".pdf")) {
      return cb(new Error("শুধু PDF ফাইল আপলোড করা যাবে।"));
    }
    cb(null, true);
  }
});

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "BharatSebak Digital Learning" }));
app.post("/api/auth/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!username || !password) return res.status(400).json({ error: "Username ও password দিন।" });
  const admin = db.prepare("SELECT id,username,password_hash,role FROM admins WHERE username=?").get(username);
  if (!admin || !(await bcrypt.compare(password, admin.password_hash))) {
    return res.status(401).json({ error: "Username অথবা password সঠিক নয়।" });
  }
  const token = jwt.sign({ id: admin.id, username: admin.username, role: admin.role }, JWT_SECRET || "local-dev-only-change-me", { expiresIn: "8h" });
  res.json({ token, admin: { id: admin.id, username: admin.username, role: admin.role }, expiresIn: 28800 });
});
app.get("/api/books", (_req, res) => {
  const books = db.prepare("SELECT id,title,class_name,subject,language,description,pdf_filename,created_at FROM books WHERE published=1 ORDER BY id DESC").all();
  res.json(books);
});
app.get("/api/books/:id", (req, res) => {
  const book = db.prepare("SELECT id,title,class_name,subject,language,description,pdf_filename FROM books WHERE id=? AND published=1").get(Number(req.params.id));
  if (!book) return res.status(404).json({ error: "বই পাওয়া যায়নি।" });
  const lessons = db.prepare("SELECT id,title,content,sort_order FROM lessons WHERE book_id=? AND published=1 ORDER BY sort_order,id").all(book.id);
  res.json({ ...book, lessons });
});
app.get("/api/lessons/:id/quiz", (req, res) => {
  const rows = db.prepare("SELECT id,question,options_json,explanation FROM quizzes WHERE lesson_id=?").all(Number(req.params.id));
  res.json(rows.map(q => ({ id:q.id, question:q.question, options:JSON.parse(q.options_json), explanation:q.explanation })));
});
app.post("/api/lessons/:id/submit", (req, res) => {
  const lessonId = Number(req.params.id);
  const answers = req.body.answers;
  if (!Array.isArray(answers)) return res.status(400).json({ error: "উত্তরের তালিকা পাঠান।" });
  const questions = db.prepare("SELECT id,answer_index,explanation FROM quizzes WHERE lesson_id=?").all(lessonId);
  const answerMap = new Map(answers.map(a => [Number(a.questionId), Number(a.answerIndex)]));
  let score = 0;
  const feedback = questions.map(q => {
    const correct = answerMap.get(q.id) === q.answer_index;
    if (correct) score++;
    return { questionId:q.id, correct, explanation:q.explanation };
  });
  db.prepare("INSERT INTO exam_results(lesson_id,score,total) VALUES(?,?,?)").run(lessonId, score, questions.length);
  res.json({ score, total: questions.length, feedback });
});
app.get("/api/admin/results", auth, requireMaster, (_req, res) => {
  res.json(db.prepare("SELECT id,lesson_id,score,total,submitted_at FROM exam_results ORDER BY id DESC LIMIT 500").all());
});
app.post("/api/admin/books", auth, requireMaster, (req, res) => {
  const title = String(req.body.title || "").trim();
  if (!title) return res.status(400).json({ error: "বইয়ের নাম আবশ্যক।" });
  const info = db.prepare("INSERT INTO books(title,class_name,subject,language,description,published) VALUES(?,?,?,?,?,?)")
    .run(title, String(req.body.class_name||"").trim(), String(req.body.subject||"").trim(), String(req.body.language||"বাংলা").trim(), String(req.body.description||"").trim(), req.body.published === false ? 0 : 1);
  res.status(201).json({ id: Number(info.lastInsertRowid), message: "বই তৈরি হয়েছে।" });
});
app.post("/api/admin/books/:id/pdf", auth, requireMaster, upload.single("pdf"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "PDF ফাইল দিন।" });
  const bookId = Number(req.params.id);
  const book = db.prepare("SELECT id FROM books WHERE id=?").get(bookId);
  if (!book) { fs.unlinkSync(req.file.path); return res.status(404).json({ error: "বই পাওয়া যায়নি।" }); }
  db.prepare("UPDATE books SET pdf_filename=? WHERE id=?").run(path.basename(req.file.filename), bookId);
  res.json({ message: "PDF আপলোড হয়েছে।", filename: req.file.filename });
});
app.get("/api/books/:id/pdf", (req, res) => {
  const book = db.prepare("SELECT pdf_filename FROM books WHERE id=? AND published=1").get(Number(req.params.id));
  if (!book?.pdf_filename) return res.status(404).json({ error: "এই বইয়ের PDF নেই।" });
  const filePath = path.join(uploadDir, path.basename(book.pdf_filename));
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: "PDF ফাইল পাওয়া যায়নি।" });
  res.type("application/pdf").sendFile(filePath);
});
app.post("/api/admin/books/:id/lessons", auth, requireMaster, (req, res) => {
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "").trim();
  if (!title || !content) return res.status(400).json({ error: "পাঠের নাম ও বিষয়বস্তু দিন।" });
  const info = db.prepare("INSERT INTO lessons(book_id,title,content,sort_order,published) VALUES(?,?,?,?,?)")
    .run(Number(req.params.id), title, content, Number(req.body.sort_order || 0), 1);
  res.status(201).json({ id:Number(info.lastInsertRowid), message:"পাঠ তৈরি হয়েছে।" });
});
app.post("/api/admin/lessons/:id/questions", auth, requireMaster, (req, res) => {
  const question = String(req.body.question || "").trim();
  const options = req.body.options;
  const answerIndex = Number(req.body.answer_index);
  if (!question || !Array.isArray(options) || options.length < 2 || options.length > 6 || !options.every(x => typeof x === "string") || !Number.isInteger(answerIndex) || answerIndex < 0 || answerIndex >= options.length) {
    return res.status(400).json({ error: "প্রশ্ন, ২–৬টি option এবং সঠিক answer_index দিন।" });
  }
  const info = db.prepare("INSERT INTO quizzes(lesson_id,question,options_json,answer_index,explanation) VALUES(?,?,?,?,?)")
    .run(Number(req.params.id), question, JSON.stringify(options), answerIndex, String(req.body.explanation || "").trim());
  res.status(201).json({ id:Number(info.lastInsertRowid), message:"প্রশ্ন তৈরি হয়েছে।" });
});

app.use(express.static(path.join(__dirname, "public")));
app.use((err, _req, res, _next) => {
  console.error(err.message);
  const status = err instanceof multer.MulterError ? 400 : 400;
  res.status(status).json({ error: err.message || "অনুরোধ সম্পন্ন করা যায়নি।" });
});
ensureAdmin().then(() => {
  app.listen(PORT, () => console.log(`BharatSebak running at http://localhost:${PORT}`));
}).catch(err => { console.error(err); process.exit(1); });
