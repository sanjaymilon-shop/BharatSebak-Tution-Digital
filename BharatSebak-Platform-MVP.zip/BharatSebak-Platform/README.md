# BharatSebak Digital Learning Platform

A deployable starter MVP for Bengali-medium digital books, lessons, quizzes, and Master Admin PDF uploads.

## Features
- Public digital library and chapter/lesson reading
- Quiz API and online quiz UI
- Master Admin login using bcrypt + JWT
- Admin PDF book upload
- SQLite database for local development
- Basic rate limiting, helmet headers, input validation, and upload type/size limits

## Requirements
- Node.js 20+
- npm

## Run locally
1. Copy `.env.example` to `.env` and set a long `JWT_SECRET`.
2. `npm install`
3. `npm start`
4. Open `http://localhost:3000`

For first admin account, set `ADMIN_USERNAME` and `ADMIN_PASSWORD` in `.env`. On first start, the server creates the admin if no account exists.

## Important
This is an MVP foundation, not a fully audited production service. Before public launch, use HTTPS, a managed database and persistent file storage, configure backups, set a strong unique secret, and review privacy/security requirements. Never commit `.env`, passwords, uploaded PDFs, or database files.
