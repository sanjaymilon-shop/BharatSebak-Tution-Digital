const $ = (s) => document.querySelector(s);
let token = "";
let booksCache = [];
let currentBook = null;

async function api(url, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const response = await fetch(url, { ...options, headers });
  const data = response.headers.get("content-type")?.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data;
}
function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
async function loadBooks() {
  const holder = $("#books");
  try {
    booksCache = await api("/api/books");
    holder.innerHTML = booksCache.length ? booksCache.map(b => `
      <article class="book"><h3>${escapeHtml(b.title)}</h3>
      <p class="muted">${escapeHtml([b.class_name,b.subject,b.language].filter(Boolean).join(" · "))}</p>
      <p>${escapeHtml(b.description || "এই বইয়ের অধ্যায় ও পাঠ দেখতে খুলুন।")}</p>
      <button data-open-book="${b.id}">বই খুলুন</button></article>`).join("") : "<p>এখনও বই যোগ করা হয়নি। Master Admin পরে বই যোগ করতে পারবেন।</p>";
    holder.querySelectorAll("[data-open-book]").forEach(btn => btn.addEventListener("click", () => openBook(btn.dataset.openBook)));
    $("#bookSelect").innerHTML = booksCache.map(b => `<option value="${b.id}">${escapeHtml(b.title)}</option>`).join("");
  } catch (e) { holder.innerHTML = `<p>${escapeHtml(e.message)} — সার্ভার চালু আছে কি না দেখুন।</p>`; }
}
async function openBook(id) {
  try {
    currentBook = await api(`/api/books/${id}`);
    $("#reader").classList.remove("hidden");
    $("#bookTitle").textContent = currentBook.title;
    $("#bookMeta").textContent = [currentBook.class_name,currentBook.subject,currentBook.language].filter(Boolean).join(" · ");
    $("#pdfArea").innerHTML = currentBook.pdf_filename ? `<p><a href="/api/books/${currentBook.id}/pdf" target="_blank" rel="noopener">PDF বই খুলুন</a></p>` : "";
    $("#lessons").innerHTML = currentBook.lessons.length ? currentBook.lessons.map(l => `<article class="lesson"><h3>${escapeHtml(l.title)}</h3><div>${escapeHtml(l.content).replace(/\n/g,"<br>")}</div><button data-quiz="${l.id}">এই পাঠের কুইজ</button><div id="quiz-${l.id}"></div></article>`).join("") : "<p>এই বইয়ে এখনও অধ্যায়/পাঠ যোগ করা হয়নি।</p>";
    $("#lessons").querySelectorAll("[data-quiz]").forEach(btn => btn.addEventListener("click", () => loadQuiz(btn.dataset.quiz)));
    $("#reader").scrollIntoView({behavior:"smooth",block:"start"});
  } catch(e) { alert(e.message); }
}
async function loadQuiz(lessonId) {
  const area = $(`#quiz-${lessonId}`);
  try {
    const questions = await api(`/api/lessons/${lessonId}/quiz`);
    if (!questions.length) { area.innerHTML = "<p>এই পাঠের কুইজ এখনও যোগ করা হয়নি।</p>"; return; }
    area.innerHTML = `<form class="quiz-form"><h4>অনলাইন পরীক্ষা</h4>${questions.map((q,i)=>`<div class="quiz-question"><strong>${i+1}. ${escapeHtml(q.question)}</strong>${q.options.map((o,j)=>`<label><input type="radio" name="q-${q.id}" value="${j}" required> ${escapeHtml(o)}</label>`).join("")}</div>`).join("")}<button>উত্তর জমা দাও</button><div class="quiz-result"></div></form>`;
    area.querySelector("form").addEventListener("submit", async ev => {
      ev.preventDefault();
      const answers = questions.map(q => ({questionId:q.id, answerIndex:Number(new FormData(ev.currentTarget).get(`q-${q.id}`))}));
      try {
        const result = await api(`/api/lessons/${lessonId}/submit`, {method:"POST",body:JSON.stringify({answers})});
        area.querySelector(".quiz-result").innerHTML = `<p class="status">তোমার ফল: ${result.score}/${result.total}</p>` + result.feedback.map((f,i)=>`<p>${f.correct?"✅ সঠিক":"↻ আবার শেখো"} — ${escapeHtml(f.explanation || "")}</p>`).join("");
      } catch(e) { area.querySelector(".quiz-result").textContent = e.message; }
    });
  } catch(e) { area.textContent = e.message; }
}
$("#refreshBooks").addEventListener("click", loadBooks);
$("#backBooks").addEventListener("click", () => $("#reader").classList.add("hidden"));
$("#loginForm").addEventListener("submit", async ev => {
  ev.preventDefault();
  const f = new FormData(ev.currentTarget);
  try {
    const data = await api("/api/auth/login", {method:"POST",body:JSON.stringify({username:f.get("username"),password:f.get("password")})});
    token = data.token;
    $("#adminPanel").classList.remove("hidden");
    $("#loginMessage").textContent = `স্বাগতম, ${data.admin.username}`;
    ev.currentTarget.reset();
  } catch(e) { $("#loginMessage").textContent = e.message; }
});
$("#logout").addEventListener("click", () => { token=""; $("#adminPanel").classList.add("hidden"); $("#loginMessage").textContent="লগআউট হয়েছে।"; });
$("#bookForm").addEventListener("submit", async ev => {
  ev.preventDefault();
  const f = new FormData(ev.currentTarget);
  const body = Object.fromEntries(f.entries());
  try {
    const result = await api("/api/admin/books",{method:"POST",body:JSON.stringify(body)});
    $("#adminMessage").textContent = `${result.message} ID: ${result.id}`;
    ev.currentTarget.reset(); await loadBooks(); $("#bookSelect").value = result.id;
  } catch(e) { $("#adminMessage").textContent = e.message; }
});
$("#pdfForm").addEventListener("submit", async ev => {
  ev.preventDefault();
  const f = new FormData(ev.currentTarget);
  const id = f.get("bookId");
  if (!id || !f.get("pdf")?.size) { $("#adminMessage").textContent="বই ও PDF নির্বাচন করুন।"; return; }
  try {
    const result = await api(`/api/admin/books/${id}/pdf`,{method:"POST",body:f});
    $("#adminMessage").textContent=result.message; await loadBooks();
  } catch(e) { $("#adminMessage").textContent=e.message; }
});
loadBooks();
